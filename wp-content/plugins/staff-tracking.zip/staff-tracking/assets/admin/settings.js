jQuery(document).ready(function ($) {
  const $form = $('#st-settings-form');
  const $status = $('#st-settings-status');
  const $submit = $('#st-settings-submit');

  if (!$form.length) return;

  // 1. Fetch current settings on page load
  function loadSettings() {
    $submit.prop('disabled', true);
    $status.text('Đang tải cấu hình...').css('color', '#787c82');

    $.ajax({
      url: STAdmin.settingsEndpoint,
      method: 'GET',
      beforeSend: function (xhr) {
        xhr.setRequestHeader('X-WP-Nonce', STAdmin.nonce);
      },
      success: function (res) {
        $('#st-setting-onsite').val(res.onsite_threshold);
        $('#st-setting-scroll').val(res.scroll_threshold);
        $('#st-setting-rate').val(res.rate_limit);
        $('#st-setting-toast').val(res.toast_duration || 5);
        $('#st-setting-payout').val(res.payout_per_kpi || 0);
        $('#st-setting-gear-pass').val(res.gear_password || '123456');
        $('#st-setting-sepay-token').val(res.sepay_webhook_token || '');
        $('#st-setting-sepay-reconcile').prop('checked', parseInt(res.sepay_auto_reconcile, 10) === 1);
        
        $status.text('');
      },
      error: function (xhr) {
        let msg = 'Không thể tải cấu hình.';
        if (xhr.responseJSON && xhr.responseJSON.message) {
          msg = xhr.responseJSON.message;
        }
        $status.text(msg).css('color', '#d63638');
      },
      complete: function () {
        $submit.prop('disabled', false);
      }
    });
  }

  loadSettings();

  // 2. Handle Save Settings on Form Submit
  $form.on('submit', function (e) {
    e.preventDefault();

    const onsite = parseInt($('#st-setting-onsite').val(), 10);
    const scroll = parseInt($('#st-setting-scroll').val(), 10);
    const rate   = parseInt($('#st-setting-rate').val(), 10);
    const toast  = parseInt($('#st-setting-toast').val(), 10);
    const payout = parseFloat($('#st-setting-payout').val());

    if (isNaN(onsite) || onsite < 1) {
      $status.text('Thời gian onsite phải lớn hơn hoặc bằng 1 giây.').css('color', '#d63638');
      return;
    }
    if (isNaN(scroll) || scroll < 1 || scroll > 100) {
      $status.text('Tỷ lệ cuộn phải nằm trong khoảng từ 1% đến 100%.').css('color', '#d63638');
      return;
    }
    if (isNaN(rate) || rate < 0) {
      $status.text('IP Rate limit phải lớn hơn hoặc bằng 0 giây.').css('color', '#d63638');
      return;
    }
    if (isNaN(toast) || toast < 1 || toast > 60) {
      $status.text('Thời gian hiển thị thông báo phải từ 1 đến 60 giây.').css('color', '#d63638');
      return;
    }
    if (isNaN(payout) || payout < 0) {
      $status.text('Định mức tiền mỗi lượt traffic phải lớn hơn hoặc bằng 0 VNĐ.').css('color', '#d63638');
      return;
    }

    $submit.prop('disabled', true).text('Đang lưu...');
    $status.text('Đang lưu cấu hình...').css('color', '#787c82');

    $.ajax({
      url: STAdmin.settingsEndpoint,
      method: 'POST',
      contentType: 'application/json',
      data: JSON.stringify({
        onsite_threshold: onsite,
        scroll_threshold: scroll,
        rate_limit: rate,
        toast_duration: toast,
        payout_per_kpi: payout,
        gear_password: $('#st-setting-gear-pass').val().trim(),
        sepay_webhook_token: $('#st-setting-sepay-token').val().trim(),
        sepay_auto_reconcile: $('#st-setting-sepay-reconcile').is(':checked') ? 1 : 0
      }),
      beforeSend: function (xhr) {
        xhr.setRequestHeader('X-WP-Nonce', STAdmin.nonce);
      },
      success: function (res) {
        $status.text('🎉 Lưu cấu hình thành công!').css('color', '#1a7a2e');
        setTimeout(function() {
          $status.text('');
        }, 3000);
      },
      error: function (xhr) {
        let msg = 'Lưu cấu hình thất bại.';
        if (xhr.responseJSON && xhr.responseJSON.message) {
          msg = xhr.responseJSON.message;
        }
        $status.text(msg).css('color', '#d63638');
      },
      complete: function () {
        $submit.prop('disabled', false).text('Lưu cài đặt');
      }
    });
  });
});
